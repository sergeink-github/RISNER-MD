 **🧚‍♀️ 𝐐𝐔𝐄𝐄𝐍 𝐌𝐈𝐊𝐔 𝐌𝐃**


</p> <p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Rubik+Dirt&size=65&pause=1000&color=F20C39F&background=FF20A500&center=true&vCenter=true&width=1000&height=150&lines=RISNER+MD;MADE+BY+SERGE+RISNER" alt="Typing SVG" 
---
1. Fork The Repo
    <br>
<a href="https://github.com/sergeink-github/RISNER-MD/fork"><img title="RISNER-MD" src="https://img.shields.io/badge/FORK RISNER-MD-h?color=black&style=for-the-badge&logo=stackshare"></a>

![forks](https://img.shields.io/github/forks/sergeink-github/RISNER-MD?label=Forks&style=social)

![stars](https://img.shields.io/github/stars/sergeink-github/RISNER-MD?style=social)




<br>
• Best and fast whatsapp bot
<br>

  <p align="center">  
  <a href="https://files.catbox.moe/n5vvij.jpg">
    <img alt="queen-miku" height="200" src="https://files.catbox.moe/n5vvij.jpg">
    
   Loading...
  <img src="https://github.com/AnderMendoza/AnderMendoza/raw/main/assets/line-neon.gif" width="100%">



---

**1.  PAIR CODE GET**
    <br>

<p align="left">
<a href='https://sahas-md-pair-web-ibx9.onrender.com/' target="_blank"><img alt='Pair Code' src='https://img.shields.io/badge/-Pair Code-darkgreen?style=for-the-badge&logo=Whatsapp&logoColor=white'/< width=120 height=39/p></a>

    
---
 **2.  Deploy To Replit**

<a href="https://replit.com"><img title="QUEEN-MIKU Deploy Replit" src="https://img.shields.io/badge/DEPLOY REPLIT-h?color=black&style=for-the-badge&logo=Replit"></a>
---
**3. Deploy to HEROKU ↓**

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/sergeink-github/RISNER-MD)

 **4.  Deploy to RENDER ↓**

<a href="https://dashboard.render.com/" target="blank"><img align="center" src="https://telegra.ph/file/c15e952f017c10e12f431.jpg" width="100" height="20" alt="Deploy bot"/></a>

---





---
**5. Deploy to GITHUB**

  WORKFLOW CODE
 ```name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```
---


## CREDITS 
# `Owner`

 <a href="https://github.com/sergeink-github"><img src="https://github.com/sergeink-github.png" width="250" height="250" alt=" Malvin King"/></a>

---
### CREATED BY:
1. ### Serge Risner

## MY YT CHANNEL

[![Youtube](https://telegra.ph/file/eebe86c26e98ffeae39ea.jpg)](https://www.youtube.com/@Risnerhosting) 
 
 ### WHATSAPP CHANNLE 👇
 <p align="left">
<a href='https://whatsapp.com/channel/0029VaxrDLEG3R3dsKW2Un2Z' target="_blank"><img alt='WhatsApp Channel' src='https://img.shields.io/badge/-WhatsApp Channel-darkgreen?style=for-the-badge&logo=Whatsapp&logoColor=white'/< width=120 height=39/p></a>


